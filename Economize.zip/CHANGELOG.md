1.4.5 - 25-JUN-2020
-------------------

* README.md: Poser badges have been added.


1.4.4 - 07-JUN-2020
-------------------

* Corrections within README.md and CHANGELOG.md.


1.4.3 - 07-JUN-2020
-------------------

* CHANGELOG.md file has been added.


1.4.2 - 06-JUN-2020
-------------------

* New installation instructions have been prepared.


1.4.1 - 06-JUN-2020
-------------------

* Initial Composer-managed package. Requirements: CodeIgniter 3.1.x, PHP >= 5.5.0, Composer enabled, PHP >= 6.1.6.
* For supporting CodeIgniter 2.x and CodeIgniter 3.0.x a manual installation of an older version of this
  library is needed, see https://github.com/ivantcholakov/codeigniter-phpmailer/tree/1.3-stable
